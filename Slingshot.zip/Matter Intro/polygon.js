function Polygon(){

}

Polygon.prototype.run = function(){
    
}