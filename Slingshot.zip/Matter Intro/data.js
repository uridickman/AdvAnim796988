function SendData(){
    this.vel;
    this.loc;
    
}